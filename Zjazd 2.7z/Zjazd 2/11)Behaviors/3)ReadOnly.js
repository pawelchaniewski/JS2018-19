//1

// var obj = {};
// Object.defineProperty(obj, 'ro',{
//     enumerable: true,
//     configurable: true,
//     writable: false,
//     value: 'Original Value'
// });
// console.log(obj.ro);


// var obj = {};
// Object.defineProperty(obj, 'ro',{
//     enumerable: true,
//     configurable: true,
//     writable: false,
//     value: 'Original Value'
// });
// obj.ro = 'Altered Value';
// console.log(obj.ro);


'use strict';
var obj = {};
Object.defineProperty(obj, 'ro',{
    enumerable: false,
    configurable: false,
    writable: false,
    value: 'Original Value'
});
obj.ro = 'Altered Value';
console.log(obj.ro);