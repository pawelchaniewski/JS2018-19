// var obj = {a:'A',
//            b:'B'};
// console.log(obj);

// var obj = {a:'A',
//            b:'B'};
// console.log(obj);
// delete obj.b;
// //obj.b = undefined;
// console.log(obj);

// var x = 6;
// delete x;
// console.log(x);

// var obj = {a:'A',
//            b:'B'};
// delete obj;
// console.log(obj);

// 'use strict';
// var x = 6;
// delete x;
// console.log(x);

'use strict';
var obj = {a:'A',
           b:'B'};
delete obj;
console.log(obj);