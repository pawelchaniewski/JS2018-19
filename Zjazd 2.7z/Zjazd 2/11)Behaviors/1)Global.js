//1

// function show(param){
//     var innerParam = param;
//     console.log(param);
// }
// show('test');


// var val1 = 'show' ;
// function show(param){
//     var innerParam = param;
//     console.log(param);
//     console.log(val1);
// }
// show('test');


// function show(param){
//     var innerParam = param;
//     console.log(param);
// }
// console.log(innerParam);
// show('test');

// function show(param){
//     var innerParam = param;
//     console.log(param);
// }
// show('test');
// console.log(innerParam);

// function show(param){
//     innerParam = param;
//     console.log(param);
// }
// console.log(innerParam);
// show('test');


// function show(param){
//     innerParam = param;
//     console.log(param);
// }
// show('test');
// console.log(innerParam);
