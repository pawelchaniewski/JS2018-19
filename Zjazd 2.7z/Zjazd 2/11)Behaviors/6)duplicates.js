// function test(x,y,x){
//     console.log(x);
// }
// test('a','b','c');

// 'use strict';
// function test(x,y,x){
//     console.log(x);
// }
// test('a','b','c');