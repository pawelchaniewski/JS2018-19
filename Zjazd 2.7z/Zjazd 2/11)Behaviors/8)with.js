// var obj = {
//     a:{
//         b:'B'
//     }
// };
// console.log(obj.a.b);

// var obj = {
//     a:{
//         b:'B'
//     }
// };
// with(obj.a){
//     console.log(b);
// }

// var obj = {
//     a:{
//         b:'B'
//     }
// };
// var b = 'C';
// with(obj.a){
//     console.log(b);
// }

// 'use strict';
// var obj = {
//     a:{
//         b:'B'
//     }
// };
// var b = 'C';
// with(obj.a){
//     console.log(b);
// }


// 'use strict';
// var obj = {
//     a:{
//         b:'B'
//     }
// };
// var b = 'C';
// (function(tempVar){
//     console.log(tempVar);
// }(obj.a.b));