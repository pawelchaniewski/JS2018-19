//1
// 'use strict';
// function show(param){
//     innerParam = param;
//     console.log(param);
// }
// show('test');
// console.log(innerParam);


// function show(param){
//     'use strict';
//     innerParam = param;
//     console.log(param);
// }
// show('test');
// console.log(innerParam);

// function show(param){
//     'use strict';
//     var innerParam = param;
//     console.log(param);
// }
// show('test');
// notCreatedVariable = 5;
// console.log(notCreatedVariable);

// 'use strict';
// notCreatedVariable = 5;

// 'use strict';
// var obj = {};
// obj.a = 'sdfs';
// console.log(obj);
