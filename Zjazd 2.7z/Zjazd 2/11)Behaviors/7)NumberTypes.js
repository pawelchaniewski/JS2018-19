// var x = 120,
// y = 012; // octal
// console.log(x+y);

// var x = 120,
// y = 0x12; // hexdec
// console.log(x+y);

// var x = 120,
// y = 0xbca; // hexdec
// console.log(x+y);

// 'use strict';
// var x = 120,
// y = 012;
// console.log(x+y);

// 'use strict';
// var x = 120,
// y = 0x12;
// console.log(x+y);

// 'use strict';
// var x = 120,
// y =  parseInt(12,7);
// console.log(x+y);